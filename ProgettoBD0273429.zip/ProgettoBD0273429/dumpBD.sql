CREATE DATABASE  IF NOT EXISTS `crm_database` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `crm_database`;
-- MySQL dump 10.13  Distrib 8.0.31, for macos12 (x86_64)
--
-- Host: 127.0.0.1    Database: crm_database
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Cliente`
--

DROP TABLE IF EXISTS `Cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Cliente` (
  `CodiceFiscale` varchar(16) NOT NULL,
  `NomeCliente` varchar(20) NOT NULL,
  `CognomeCliente` varchar(20) NOT NULL,
  `DataRegistrazioneCliente` date NOT NULL,
  `IndirizzoCliente` varchar(40) NOT NULL,
  `DataDiNascitaCliente` date NOT NULL,
  PRIMARY KEY (`CodiceFiscale`),
  KEY `IDX_Eta` (`DataDiNascitaCliente`),
  KEY `IDX_DataRegistrazione` (`DataRegistrazioneCliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cliente`
--

LOCK TABLES `Cliente` WRITE;
/*!40000 ALTER TABLE `Cliente` DISABLE KEYS */;
INSERT INTO `Cliente` VALUES ('CLZMTT99L24H501T','Matteo','Calzetta','2023-09-15','Via ottaviano di montecelio 30','1999-07-24'),('TLMLGU99L31H501Q','Luigi','Talamo','2023-09-15','Via castelfarfa 40','1999-07-31');
/*!40000 ALTER TABLE `Cliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `contolloEtaCliente` BEFORE INSERT ON `cliente` FOR EACH ROW BEGIN
  DECLARE age INT;
  SET age = TIMESTAMPDIFF(YEAR, NEW.DataDiNascitaCliente, CURRENT_DATE());
  IF age < 18 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'L\'età del cliente deve essere maggiore di 18 anni';
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `Email`
--

DROP TABLE IF EXISTS `Email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Email` (
  `Email` varchar(45) NOT NULL,
  `Cliente` varchar(16) NOT NULL,
  PRIMARY KEY (`Email`),
  KEY `Cliente_idx` (`Cliente`),
  CONSTRAINT `FK_Email_Cliente` FOREIGN KEY (`Cliente`) REFERENCES `Cliente` (`CodiceFiscale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Email`
--

LOCK TABLES `Email` WRITE;
/*!40000 ALTER TABLE `Email` DISABLE KEYS */;
INSERT INTO `Email` VALUES ('kalzmatteo@gmail.com','CLZMTT99L24H501T');
/*!40000 ALTER TABLE `Email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Offerta`
--

DROP TABLE IF EXISTS `Offerta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Offerta` (
  `CodiceOfferta` int NOT NULL,
  `TipoOfferta` varchar(45) NOT NULL,
  `NomeOfferta` varchar(45) NOT NULL,
  `Condizione` text,
  `DataInizio` date NOT NULL,
  `DataFine` date NOT NULL,
  PRIMARY KEY (`CodiceOfferta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Offerta`
--

LOCK TABLES `Offerta` WRITE;
/*!40000 ALTER TABLE `Offerta` DISABLE KEYS */;
INSERT INTO `Offerta` VALUES (1,'Sconto','Sconto TIM','Non ci sono condizioni per proporre l\'offerta.','2023-10-01','2024-01-01'),(2,'Promozione','2x1 presso decathlon',NULL,'2023-12-01','2024-01-01');
/*!40000 ALTER TABLE `Offerta` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `VerificaDataInizioOfferta` BEFORE INSERT ON `offerta` FOR EACH ROW BEGIN
    DECLARE dataOdierna DATE;
    SET dataOdierna = CURDATE(); -- Ottieni la data odierna

    IF NEW.DataInizio <= dataOdierna THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La data di inizio dell''offerta deve essere posteriore alla data odierna.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `VerificaDateOfferta` BEFORE INSERT ON `offerta` FOR EACH ROW BEGIN
    IF NEW.DataInizio >= NEW.DataFine THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La data di inizio dell''offerta deve essere antecedente alla data di fine.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `OffertaPropostaAppuntamento`
--

DROP TABLE IF EXISTS `OffertaPropostaAppuntamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OffertaPropostaAppuntamento` (
  `DataChiamata` date NOT NULL,
  `OraChiamata` time NOT NULL,
  `Cliente` varchar(16) NOT NULL,
  `Rapporto` varchar(200) NOT NULL,
  `IdentificativoOperatore` varchar(45) DEFAULT NULL,
  `StatoAccettazione` varchar(45) NOT NULL,
  `Offerta` int NOT NULL,
  `Appuntamento` datetime DEFAULT NULL,
  `SedeAzienda` int DEFAULT NULL,
  PRIMARY KEY (`Cliente`,`DataChiamata`,`OraChiamata`),
  KEY `FK_OffertaProposta_Offerta_idx` (`Offerta`),
  KEY `FK_OffertaProposta_SedeAzienda_idx` (`SedeAzienda`),
  KEY `IDX_Rapporto` (`Rapporto`),
  CONSTRAINT `FK_OffertaProposta_Cliente` FOREIGN KEY (`Cliente`) REFERENCES `Cliente` (`CodiceFiscale`),
  CONSTRAINT `FK_OffertaProposta_Offerta` FOREIGN KEY (`Offerta`) REFERENCES `Offerta` (`CodiceOfferta`),
  CONSTRAINT `FK_OffertaProposta_SedeAzienda` FOREIGN KEY (`SedeAzienda`) REFERENCES `SedeAzienda` (`CodiceSede`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OffertaPropostaAppuntamento`
--

LOCK TABLES `OffertaPropostaAppuntamento` WRITE;
/*!40000 ALTER TABLE `OffertaPropostaAppuntamento` DISABLE KEYS */;
INSERT INTO `OffertaPropostaAppuntamento` VALUES ('2023-09-15','14:00:00','CLZMTT99L24H501T','cliente ostile',NULL,'Rifiutata',1,NULL,NULL),('2023-09-16','10:00:00','CLZMTT99L24H501T','cliente ostile',NULL,'Rifiutata',1,NULL,NULL),('2023-09-15','10:40:00','TLMLGU99L31H501Q','cliente amichevole','','Rifiutata',1,'2023-09-16 10:00:00',1),('2023-09-15','13:40:00','TLMLGU99L31H501Q','cliente amichevole','OP1','Accettata',1,'2023-09-16 10:00:00',1);
/*!40000 ALTER TABLE `OffertaPropostaAppuntamento` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ControlloAppuntamentoVuoto` BEFORE INSERT ON `offertapropostaappuntamento` FOR EACH ROW BEGIN
    IF NOT ((NEW.Appuntamento IS NULL AND NEW.SedeAzienda IS NULL) OR (NEW.Appuntamento IS NOT NULL AND NEW.SedeAzienda IS NOT NULL)) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'È necessario specificare sia Appuntamento che Sede Azienda oppure lasciarli entrambi vuoti.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ControlloDataAppuntamento` BEFORE INSERT ON `offertapropostaappuntamento` FOR EACH ROW BEGIN
    IF NEW.Appuntamento IS NOT NULL AND NEW.DataChiamata > NEW.Appuntamento THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La data di Appuntamento deve essere posteriore a quella di DataChiamata.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `ControlloStatoAppuntamento` BEFORE INSERT ON `offertapropostaappuntamento` FOR EACH ROW BEGIN
    IF NEW.StatoAccettazione NOT IN ('Accettato', 'Rifiutato') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'L\'esito dell\'offerta proposta deve essere Accettato o Rifiutato.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `CodiceSeOffertaAccettata` BEFORE INSERT ON `offertapropostaappuntamento` FOR EACH ROW BEGIN
    IF (NEW.StatoAccettazione = 'Accettata' AND NEW.IdentificativoOperatore IS NULL) OR 
       (NEW.StatoAccettazione = 'Rifiutata' AND NEW.IdentificativoOperatore IS NOT NULL) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'L\'identificativo dell\'operatore deve essere presente solo quando lo stato dell\'offerta è Accettato.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `SedeAzienda`
--

DROP TABLE IF EXISTS `SedeAzienda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SedeAzienda` (
  `CodiceSede` int NOT NULL,
  `Regione` varchar(30) NOT NULL,
  `Citta` varchar(30) NOT NULL,
  `Indirizzo` varchar(50) NOT NULL,
  PRIMARY KEY (`CodiceSede`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SedeAzienda`
--

LOCK TABLES `SedeAzienda` WRITE;
/*!40000 ALTER TABLE `SedeAzienda` DISABLE KEYS */;
INSERT INTO `SedeAzienda` VALUES (1,'Lazio','Roma','Via roma 123'),(2,'Lombardia','Milano','Via milano 123'),(3,'Piemonte','Torino','Via torino 123');
/*!40000 ALTER TABLE `SedeAzienda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Telefono`
--

DROP TABLE IF EXISTS `Telefono`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Telefono` (
  `Telefono` varchar(15) NOT NULL,
  `Cliente` varchar(16) NOT NULL,
  PRIMARY KEY (`Telefono`),
  KEY `FK_Telefono_Cliente_idx` (`Cliente`),
  CONSTRAINT `FK_Telefono_Cliente` FOREIGN KEY (`Cliente`) REFERENCES `Cliente` (`CodiceFiscale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Telefono`
--

LOCK TABLES `Telefono` WRITE;
/*!40000 ALTER TABLE `Telefono` DISABLE KEYS */;
INSERT INTO `Telefono` VALUES ('3924687046','CLZMTT99L24H501T'),('3349843457','TLMLGU99L31H501Q');
/*!40000 ALTER TABLE `Telefono` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Utente`
--

DROP TABLE IF EXISTS `Utente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Utente` (
  `CodiceUtente` varchar(10) NOT NULL,
  `Password` char(32) NOT NULL,
  `Ruolo` enum('operatore','segreteria') NOT NULL,
  PRIMARY KEY (`CodiceUtente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Utente`
--

LOCK TABLES `Utente` WRITE;
/*!40000 ALTER TABLE `Utente` DISABLE KEYS */;
INSERT INTO `Utente` VALUES ('OP1','fdc51f63fd7652738a7530cf34319b8a','operatore'),('SEGR0','6c1dbd0c2a6ed02b2553523f13b8a8af','segreteria');
/*!40000 ALTER TABLE `Utente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'crm_database'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `EliminaOfferteScadute` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `EliminaOfferteScadute` ON SCHEDULE EVERY 1 DAY STARTS '2023-09-15 13:20:30' ON COMPLETION NOT PRESERVE ENABLE DO DELETE FROM Offerta WHERE DataFine > CURDATE() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `EliminaVecchiRapporti` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `EliminaVecchiRapporti` ON SCHEDULE EVERY 1 MONTH STARTS '2023-09-15 13:21:07' ON COMPLETION NOT PRESERVE ENABLE DO DELETE FROM OffertaPropostaAppuntamento    
WHERE DATEDIFF(NOW(), DataChiamata) > 1825 */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'crm_database'
--
/*!50003 DROP PROCEDURE IF EXISTS `CreazioneAppuntamento` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `CreazioneAppuntamento`(
    IN var_DataChiamata DATE,
    IN var_OraChiamata TIME,
    IN var_Cliente VARCHAR(16),
    IN var_Appuntamento DATETIME,
    IN var_SedeAzienda INT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK; -- Annulla la transazione in caso di errore
        RESIGNAL; -- Ri-lancia l'eccezione
    END;
    
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    START TRANSACTION;
    UPDATE OffertaPropostaAppuntamento
    SET Appuntamento = var_Appuntamento, SedeAzienda = var_SedeAzienda
    WHERE DataChiamata = var_DataChiamata
        AND OraChiamata = var_OraChiamata
        AND Cliente = var_Cliente;

    COMMIT; -- Conferma la transazione
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `EliminaCliente` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminaCliente`(
    IN p_CodiceFiscale VARCHAR(16)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK; -- Annulla la transazione in caso di errore
        RESIGNAL; -- Ri-lancia l'eccezione
    END;

    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    START TRANSACTION;
		DELETE FROM OffertaPropostaAppuntamento WHERE Cliente = p_CodiceFiscale;
		DELETE FROM Telefono WHERE Cliente = p_CodiceFiscale;
		DELETE FROM Email WHERE Cliente = p_CodiceFiscale;
		DELETE FROM Cliente WHERE CodiceFiscale = p_CodiceFiscale;
	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GeneraReportContatti` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GeneraReportContatti`(
    IN p_DataInizio DATE,
    IN p_DataFine DATE
)
BEGIN
    -- Imposta il livello di isolamento READ COMMITTED
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;

    -- Inizia una transazione
    START TRANSACTION;

    -- Crea una tabella temporanea per raccogliere i risultati del report
    CREATE TEMPORARY TABLE TempReport (
        CodiceFiscaleCliente VARCHAR(16) PRIMARY KEY,
        NomeCliente VARCHAR(20),
        CognomeCliente VARCHAR(20),
        Contatti INT DEFAULT 0,
        OfferteAccettate INT DEFAULT 0
    );

    -- Popola la tabella temporanea con i dati del report
    INSERT INTO TempReport (CodiceFiscaleCliente, NomeCliente, CognomeCliente)
    SELECT CodiceFiscale, NomeCliente, CognomeCliente
    FROM Cliente;

    -- Aggiorna il conteggio dei contatti per ciascun cliente
    UPDATE TempReport AS tr
    SET tr.Contatti = (
        SELECT COUNT(*)
        FROM OffertaPropostaAppuntamento
        WHERE DataChiamata BETWEEN p_DataInizio AND p_DataFine
        AND tr.CodiceFiscaleCliente = OffertaPropostaAppuntamento.Cliente
    );

    -- Aggiorna il conteggio delle offerte accettate per ciascun cliente
    UPDATE TempReport AS tr
    SET tr.OfferteAccettate = (
        SELECT COUNT(*)
        FROM OffertaPropostaAppuntamento
        WHERE DataChiamata BETWEEN p_DataInizio AND p_DataFine
        AND tr.CodiceFiscaleCliente = OffertaPropostaAppuntamento.Cliente
        AND StatoAccettazione = 'Accettata'
    );

    -- Seleziona il report finale
    SELECT * FROM TempReport;

    -- Elimina la tabella temporanea
    DROP TEMPORARY TABLE IF EXISTS TempReport;

    -- Commit della transazione
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InserisciAppuntamento` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InserisciAppuntamento`(
    IN var_DataChiamata DATE,
    IN var_OraChiamata TIME,
    IN var_Cliente VARCHAR(16),
    IN var_Appuntamento DATETIME,
    IN var_SedeAzienda INT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK; -- Annulla la transazione in caso di errore
        RESIGNAL; -- Ri-lancia l'eccezione
    END;
    
	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    START TRANSACTION;
    UPDATE OffertaPropostaAppuntamento
    SET Appuntamento = var_Appuntamento, SedeAzienda = var_SedeAzienda
    WHERE DataChiamata = var_DataChiamata
        AND OraChiamata = var_OraChiamata
        AND Cliente = var_Cliente;

    COMMIT; -- Conferma la transazione
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InserisciCliente` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InserisciCliente`(
    IN p_CodiceFiscale VARCHAR(16),
    IN p_NomeCliente VARCHAR(20),
    IN p_CognomeCliente VARCHAR(20),
    IN p_IndirizzoCliente VARCHAR(40),
    IN p_DataDiNascitaCliente DATE,
    IN p_Telefono VARCHAR(15)
)
BEGIN
	DECLARE clienteEsistente INT;
    DECLARE exit HANDLER FOR SQLEXCEPTION
		BEGIN
			ROLLBACK; ## Annullamento transazione
			RESIGNAL; ## Ridirezione Segnale al Client
	END;
    
    -- Verifica che il codice fiscale sia esattamente di 16 caratteri
    IF LENGTH(p_CodiceFiscale) != 16 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Il codice fiscale deve essere esattamente di 16 caratteri.';
    ELSE
        -- Verifica se il cliente con lo stesso codice fiscale è già presente nel database
        SELECT COUNT(*) INTO clienteEsistente FROM Cliente WHERE CodiceFiscale = p_CodiceFiscale;

        IF clienteEsistente > 0 THEN
            -- Il cliente con lo stesso codice fiscale è già presente, genera un messaggio di errore
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cliente già iscritto con questo codice fiscale.';
        ELSE
			SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            START TRANSACTION;
            -- Inserisci il nuovo cliente nella tabella Cliente
            INSERT INTO Cliente (CodiceFiscale, NomeCliente, CognomeCliente, DataRegistrazioneCliente, IndirizzoCliente, DataDiNascitaCliente)
            VALUES (p_CodiceFiscale, p_NomeCliente, p_CognomeCliente, NOW(), p_IndirizzoCliente, p_DataDiNascitaCliente);
            COMMIT;
            BEGIN
            CALL InserisciTelefono(p_Telefono, p_CodiceFiscale);
            END;
        END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InserisciEmail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InserisciEmail`(
    IN p_Email VARCHAR(45),
    IN p_Cliente VARCHAR(16)
    )
BEGIN
    DECLARE exit HANDLER FOR SQLEXCEPTION
	BEGIN
		ROLLBACK; ## Annullamento transazione
		RESIGNAL; ## Ridirezione Segnale al Client
	END;

    -- Verifica se il cliente (codice fiscale) esiste nel database
    IF NOT EXISTS (SELECT 1 FROM Cliente WHERE CodiceFiscale = p_Cliente) THEN
        -- Genera un messaggio di errore se il cliente non esiste
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Il cliente con il codice fiscale specificato non esiste nel database.';
    ELSE
        -- Verifica se il numero di telefono esiste già nella tabella Telefono
        IF EXISTS (SELECT 1 FROM Email WHERE Email = p_Email) THEN
            -- Genera un messaggio di errore se il numero di telefono esiste già
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'L\'email specificata è già presente nel database.';
        ELSE
            -- Inserisci il nuovo numero di telefono nella tabella Telefono
            SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            START TRANSACTION;
            INSERT INTO Email (Email, Cliente)
            VALUES (p_Email, p_Cliente);
            COMMIT;
        END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InserisciOfferta` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InserisciOfferta`(
    IN p_CodiceOfferta INT,
    IN p_TipoOfferta VARCHAR(45),
    IN p_NomeOfferta VARCHAR(45),
    IN p_Condizione TEXT(100),
    IN p_DataInizio DATE,
    IN p_DataFine DATE
    )
BEGIN
	DECLARE exit HANDLER FOR SQLEXCEPTION
	BEGIN
		ROLLBACK; ## Annullamento transazione
		RESIGNAL; ## Ridirezione Segnale al Client
	END;
    -- Verifica se esiste un'offerta con lo stesso codice
    IF EXISTS (SELECT 1 FROM Offerta WHERE CodiceOfferta = p_CodiceOfferta) THEN
        -- Genera un messaggio di errore
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Offerta con lo stesso codice già presente nel database.';
    ELSE
        -- Inserisci la nuova offerta nella tabella Offerta
        SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        START TRANSACTION;
        INSERT INTO Offerta (CodiceOfferta, TipoOfferta, NomeOfferta, Condizione, DataInizio, DataFine)
        VALUES (p_CodiceOfferta, p_TipoOfferta, p_NomeOfferta, p_Condizione, p_DataInizio, p_DataFine);
        COMMIT;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InserisciOffertaPropostaAppuntamento` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InserisciOffertaPropostaAppuntamento`(
    IN p_DataChiamata DATE,
    IN p_OraChiamata TIME,
    IN p_Cliente VARCHAR(16),
    IN p_Rapporto VARCHAR(200),
    IN p_IdentificativoOperatore VARCHAR(45),
    IN p_StatoAccettazione VARCHAR(45),
    IN p_Offerta INT,
    IN p_Appuntamento DATETIME,
    IN p_SedeAzienda INT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
    START TRANSACTION;

    -- Inserisci i dati nella tabella OffertaPropostaAppuntamento
    INSERT INTO OffertaPropostaAppuntamento (DataChiamata, OraChiamata, Cliente, Rapporto, IdentificativoOperatore, StatoAccettazione, Offerta, Appuntamento, SedeAzienda)
    VALUES (p_DataChiamata, p_OraChiamata, p_Cliente, p_Rapporto, p_IdentificativoOperatore, p_StatoAccettazione, p_Offerta, p_Appuntamento, p_SedeAzienda);

    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InserisciSedeAzienda` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InserisciSedeAzienda`(
    IN p_CodiceSede INT,
    IN p_Regione VARCHAR(30),
    IN p_Città VARCHAR(30),
    IN p_Indirizzo VARCHAR(50)
    )
BEGIN
	DECLARE exit HANDLER FOR SQLEXCEPTION
		BEGIN
			ROLLBACK; ## Annullamento transazione
			RESIGNAL; ## Ridirezione Segnale al Client
	END;
    IF EXISTS (SELECT 1 FROM SedeAzienda WHERE CodiceSede = p_CodiceSede) THEN
        
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Sede con lo stesso codice già presente nel database.';
    ELSE
		SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
        START TRANSACTION;
			INSERT INTO SedeAzienda (CodiceSede, Regione, Citta, Indirizzo)
			VALUES (p_CodiceSede, p_Regione, p_Citta, p_Indirizzo);
        COMMIT;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InserisciTelefono` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InserisciTelefono`(
    IN p_Telefono VARCHAR(15),
    IN p_Cliente VARCHAR(16)
    )
BEGIN
    DECLARE exit HANDLER FOR SQLEXCEPTION
	BEGIN
		ROLLBACK; ## Annullamento transazione
		RESIGNAL; ## Ridirezione Segnale al Client
	END;

    -- Verifica se il cliente (codice fiscale) esiste nel database
    IF NOT EXISTS (SELECT 1 FROM Cliente WHERE CodiceFiscale = p_Cliente) THEN
        -- Genera un messaggio di errore se il cliente non esiste
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Il cliente con il codice fiscale specificato non esiste nel database.';
    ELSE
        -- Verifica se il numero di telefono esiste già nella tabella Telefono
        IF EXISTS (SELECT 1 FROM Telefono WHERE Telefono = p_Telefono) THEN
            -- Genera un messaggio di errore se il numero di telefono esiste già
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Il numero di telefono specificato è già presente nel database.';
        ELSE
            -- Inserisci il nuovo numero di telefono nella tabella Telefono
            SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
            START TRANSACTION;
            INSERT INTO Telefono (Telefono, Cliente)
            VALUES (p_Telefono, p_Cliente);
            COMMIT;
        END IF;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `Login`(in p_Codice varchar(10), in p_Password varchar(32), out var_role INT)
BEGIN
       declare var_user_role ENUM('operatore', 'segreteria');
select `ruolo` from `Utente`
where `CodiceUtente` = p_Codice
        and `Password` = md5(p_Password)
        into var_user_role;
-- See the corresponding enum in the client
if var_user_role = 'Segreteria' then
       set var_role = 2;
end if;
if var_user_role = 'Operatore' then
       set var_role = 1;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `SelezionaDatiPerCliente` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `SelezionaDatiPerCliente`(
    IN p_Cliente VARCHAR(30),
    OUT p_DataChiamata DATE,
    OUT p_Resoconto TEXT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK; -- Annulla la transazione in caso di errore
        RESIGNAL; -- Ri-lancia l'eccezione
    END;

    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    START TRANSACTION;

    -- Seleziona i dati dalla tabella OffertaPropostaAppuntamento
    SELECT DataChiamata, Resoconto
    INTO p_DataChiamata, p_Resoconto
    FROM OffertaPropostaAppuntamento
    WHERE Cliente = p_Cliente;

    COMMIT; -- Conferma la transazione
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VisualizzaClienti` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `VisualizzaClienti`(
    IN p_EtaMin INT,
    IN p_AnnoRegistrazioneMin INT
)
BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
		BEGIN
			ROLLBACK; -- Annulla la transazione in caso di errore
			RESIGNAL; -- Ri-lancia l'eccezione
    END;
    -- Imposta il livello di isolamento READ UNCOMMITTED
    SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
	-- Inizia una transazione
    START TRANSACTION;

    -- Seleziona le informazioni desiderate dalle tabelle Cliente e Telefono
    SELECT
        C.CodiceFiscale,
        C.NomeCliente,
        C.CognomeCliente,
        T.Telefono
    FROM
        Cliente AS C
    JOIN
        Telefono AS T
    ON
        C.CodiceFiscale = T.Cliente
    WHERE
        TIMESTAMPDIFF(YEAR, C.DataDiNascitaCliente, CURRENT_DATE()) >= p_EtaMin
        AND TIMESTAMPDIFF(YEAR, C.DataRegistrazioneCliente, CURRENT_DATE()) >= p_AnnoRegistrazioneMin
    Order BY
        C.NomeCliente;  -- Ordina in base al nome del cliente

    -- Esegui il commit della transazione
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VisualizzaOfferte` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `VisualizzaOfferte`()
BEGIN
    -- Imposta il livello di isolamento READ COMMITTED
    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

    -- Inizia una transazione
    START TRANSACTION;

    -- Seleziona tutte le offerte dalla tabella Offerta
    SELECT CodiceOfferta, TipoOfferta, NomeOfferta, Condizione, DataInizio, DataFine
    FROM Offerta;

    -- Commit della transazione
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VisualizzaRapporto` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `VisualizzaRapporto`(
    IN p_Cliente VARCHAR(16)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK; -- Annulla la transazione in caso di errore
        RESIGNAL; -- Ri-lancia l'eccezione
    END;

    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    START TRANSACTION;

    -- Seleziona i dati dalla tabella OffertaPropostaAppuntamento
    SELECT DataChiamata, Rapporto
    FROM OffertaPropostaAppuntamento
    WHERE Cliente = p_Cliente;

    COMMIT; -- Conferma la transazione
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `VisualizzaSedeAzienda` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `VisualizzaSedeAzienda`(
    IN var_Regione VARCHAR(45)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL; 
    END;

    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    START TRANSACTION;

    IF var_Regione IS NOT NULL AND var_Regione != '' THEN
        SELECT CodiceSede, Regione, Citta, Indirizzo
        FROM SedeAzienda
        WHERE Regione LIKE CONCAT('%', var_Regione, '%');
    ELSE
        
        SELECT CodiceSede, Regione, Citta, Indirizzo
        FROM SedeAzienda;
    END IF;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-15 16:47:07
